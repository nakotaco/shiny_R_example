# Example Shiny app

This is an example application written in R with Shiny.
The main purpose of this example is to illustrate Shiny for a data filtering application. 

